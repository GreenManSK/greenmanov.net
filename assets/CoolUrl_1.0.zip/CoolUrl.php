<?php

/**
 * CoolUrl
 *
 * @autor Lukáš Kurčík
 * @copyright Copyright (c) 2011 Lukaš Kurčík
 * @version 1.0
 *
 */
class CoolUrl {

    private $model, $regExp, $values;
    static $proChars = array('', ' ', '<', '>', '#', '%', '{', '}', '|', '\\', '^', '~', '[', ']', ';', '?', '@', "'", '"', ':', '=', '*', '&'); //Zakázané znaky v URL

    /*
     * @param string Model ako má vypadať URL adresa po názvu súboru. Premenné sa dávajú do @, napr. @premenná@. Platia pri nich pravidlá ako pri premenných v PHP.
     * @param string Znak ktorý oddeľuje jednotlivé premenné a nachádza sa na konci URL.
     * @param array Pole do ktorého sa majú premenné z URL uložiť. Defaultne je to $_GET.
     * 
     * @return bool True v prípade že URL sa spracovala úspešne, v opačnom prípade false.
     */
    public function __construct($model, $separator = '/', &$array = NULL) {
        $this->setSeparator($separator);
        $this->setModel('/' . $model . $separator);
        if ($array == NULL) {
            $array = &$_GET;
        }

        if ($_SERVER['PATH_INFO'] != '') {
            if (subStr($_SERVER['PATH_INFO'], -1) != $this->separator) {
                $get = '';
                if ($_SERVER['QUERY_STRING'] != '')
                    $get = '?' . $_SERVER['QUERY_STRING'];
                header("Location: " . $this->getCurrentUrl() . $_SERVER['PATH_INFO'] . $this->separator . $get, true, 301);
                exit();
            }
        }
        $urlValues = $this->chceckUrl($_SERVER['PATH_INFO']);

        if ($urlValues === false) {
            $values = array();
            foreach ($this->values as $key) {
                if (isset($array[$key])) {
                    $values[$key] = $_GET[$key];
                    unset($_GET[$key]);
                } else
                    return false;
            }
            $get = http_build_query($_GET);
            if ($get != '')
                $get = '?' . str_replace("&amp;", "&", $get);
            header("Location: " . $this->getCurrentUrl() . $this->createUrl($values) . $get, true, 301);
            exit();
        } else {
            foreach ($urlValues as $key => $value) {
                $array[$key] = $value;
            }
            return true;
        }
    }

    public function chceckUrl($url) {
        preg_match($this->regExp, $url, $match);

        $return = array();
        foreach ($this->values as $key) {
            if (!isset($match[$key]))
                return false;
            if (isset($match[$key]))
                $return[$key] = urldecode($match[$key]);
        }

        return $return;
    }

    public function getSeparator() {
        return $this->separator;
    }

    public function setSeparator($value) {
        if (in_array($value, self::$proChars)) {
            throw new Exception($value . " nemôže byť použitý ako oddelovač v URL.");
        } else {
            $this->separator = $value;
        }

        return $this;
    }

    public function getModel() {
        return $this->model;
    }

    public function setModel($value) {
        $this->model = $value;

        $regExp = "~@(.*?)@~";

		$value = str_replace('/', $this->separator, $value);
        preg_match_all($regExp, $value, $mat);
        $this->values = $mat[1];
        $regExp = preg_replace($regExp, "(?P<$1>.*?)", $value, count($this->values) - 1);
        $regExp = preg_replace("~@(.*)@~", "(?P<$1>.*)" . $this->separator, $regExp);

        if (subStr($regExp, -1) == $this->separator) {
            $regExp = subStr($regExp, 0, -1);
        }
        $this->regExp = '~' . $regExp . '~';

        return $this;
    }

    public function getCurrentUrl() {
        $http = "http";
        if ($_SERVER["HTTPS"] == "on")
            $http = "https";
        $port = "";
        if ($_SERVER["SERVER_PORT"] != "80")
            $port = ":" . $_SERVER["SERVER_PORT"];

        return $http . "://" . $_SERVER["SERVER_NAME"] . $port . $_SERVER['SCRIPT_NAME'];
    }

    public function createUrl($values) {
        $url = $this->model;
        foreach ($values as $key => $value) {
            $url = str_replace('@' . $key . '@', $value, $url);
        }
        
        return $url;
    }
}